clear all
clc
close all

% By Zhiliang Wei, August 12, 2016, The Johns Hopkins University
% Modified on Mar. 22, 2017 for measuring brain weight
% Modified on Aug. 15, 2022

% Reading in the last processing
fp=fopen('W_Filepath.txt' );
filepath=fscanf(fp,'%s',1);
fclose(fp);
if exist(filepath)
    filepath=uigetdir(filepath);
else
    filepath=uigetdir();
end

% Locate the anatomical scans
if exist([filepath filesep 'Anat.txt'])
    expno=load([filepath filesep 'Anat.txt']);
else
    expno=W_FindScan(filepath,'RARE');
    dlmwrite([filepath filesep 'Anat.txt'],expno);
end

% Choose the dataset to process
for ni=1:length(expno)
    liststr{ni}=num2str(expno(ni));
end
[lists listv]=listdlg('PromptString','Select a dataset:',...
    'SelectionMode','Single',...
    'ListString',liststr);
expno=expno(lists);

% Save the filepath
fp=fopen('W_FilePath.txt','w');
fprintf(fp,'%s',filepath);
fclose(fp);

% Parameter extractions
filename=[filepath filesep num2str(expno)];
Para=W_ImgParaAbs(filename)

% Exporting data
[Image NX NY NI]=read_2dseq_v3(filepath,expno,1);
scale=size(Image); 
msmask=zeros(scale);

H=figure;
for ni=scale(3):-1:1
    imshow(Image(:,:,ni),[],'initialmagnification','fit');
    title(['Slice Num: ' num2str(ni)]);
    msmask(:,:,ni)=roipoly;
end
close(H);

% Save the Mask
ProcNum=load('W_Para.txt');
[PathTempA PathTempB]=fileparts(filepath);
ResPath=['Results' filesep 'BrainVol_' num2str(ProcNum) '_' PathTempB];
if ~exist(ResPath)
    mkdir(ResPath);
end

W_MSplot(Image,[5 8],1,[]);
title('Original Image');
saveas(gcf,[ResPath filesep 'Orig.tif']);

% Brain ROI
ImageNew=Image.*msmask;
W_MSplot(ImageNew,[5 8],1,[]);
title('Filtered Image');
saveas(gcf,[ResPath filesep 'New.tif']);
W_MSplot(msmask,[5 8],1,[]);
title('Mask Image');
saveas(gcf,[ResPath filesep 'msmask.tif']);

% Save the results
save([ResPath filesep 'Image.mat'],'Image');
save([ResPath filesep 'msmask.mat'],'msmask');
save([ResPath filesep 'ImageNew.mat'],'ImageNew');
Anat=ImageNew;
save([filepath filesep 'Anat.mat'],'Anat');
AnatMask=msmask;
save([filepath filesep 'AnatMask.mat'],'AnatMask');

% Calculate the brain volume
BrainVol.Area=squeeze(sum(sum(msmask,1),2));
BrainVol.Vol=sum(BrainVol.Area).*(prod(Para.ROI)).*(Para.thickness)/10/prod(Para.size);
save([ResPath filesep 'BrainVol.mat'],'BrainVol');
% Increase the processing number after finishing
dlmwrite('W_Para.txt',ProcNum+1);
fp=fopen([ResPath filesep 'BrainVolume.txt'],'w');
fprintf(fp,'%s\r\n',[num2str(BrainVol.Vol) ' cm3']);
fclose(fp);
BrainVol
