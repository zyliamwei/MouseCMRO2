function y=W_GTTest(data)
% for performing un-paired t-test for multiple groups
scale=size(data);
pmat=zeros(scale(2),scale(2));
for mi=1:scale(2)
    for ni=1:scale(2)
        [m n p]=ttest2(data(:,mi),data(:,ni));
        pmat(mi,ni)=n;
    end
end
y=pmat;
end