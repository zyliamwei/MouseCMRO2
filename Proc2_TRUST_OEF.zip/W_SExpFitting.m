function y=W_SExpFitting(te,val,choice)
% Performing the monoexponential fitting
fun=@(beta,x)(beta(1).*exp(-x./beta(2)));
beta=nlinfit(te,val,fun,[max(val) 40]);
if choice==1
figure;
hold on;
plot(te,val,'ro');
xtemp=linspace(min(te),max(te),100);
plot(xtemp,beta(1).*exp(-xtemp./beta(2)),'b-');
R2=1-sum(( beta(1).*exp(-te./beta(2))-val ).^2 )./sum( ( val-mean(val) ).^2 );
title(['Relaxation = ' num2str(beta(2)) ' ms with R2 = ' num2str(R2)]);
end
y=beta(2);
end