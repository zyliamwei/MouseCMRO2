function y=W_MonoExpFitting(ListTE,ListAmpV,eTE,str)
% Performing the monoexponential fitting
[Coeff,resid,jacob]=nlinfit(ListTE/1000, ListAmpV,'monexp_model',[100,10]);
ConInt=nlparci(Coeff,resid,jacob); %95 confidence
eT2=1000./Coeff(2);
res=1000./ConInt;
delta_R2=ConInt(2,2)-ConInt(2,1);

SucTE=linspace(min(eTE),max(eTE),50);
SucAmp=Coeff(1)*exp(-SucTE./eT2);
plot(ListTE, ListAmpV,'*',SucTE,SucAmp,'r-');
title([str '   T_2 = ', num2str(W_DigitS(eT2,2)),...
    ' ms ','     \DeltaR_2 = ',num2str(W_DigitS(delta_R2,2)),' ms ']);
xlabel('eTE (ms)');ylabel('Intensity');
axis([0 1.1*max(eTE) 0 1.1*max(ListAmpV)]);
y=[eT2 delta_R2];
end