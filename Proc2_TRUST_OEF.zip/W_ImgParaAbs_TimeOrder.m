function y=W_ImgParaAbs(path)
% Abstracting imaging slice information from the BRUKER data
% Programmed by Zhiliang Wei on July 3rd, 2016 at Park Building 
% The Johns Hopkins University
TIME=cputime;
Slice.path=path(1:end);
% Initial the parameters

Slice.TP=[];

%<------------------------ Method -------------------->
path1=[path filesep 'method'];
if exist(path1)
filepath=fopen(path1);
while ~feof(filepath)
    temp=fscanf(filepath,'%s',1);
    if W_strcmp('##OWNER=',temp)==1
        temp=fscanf(filepath,'%s',1);
        temp=fscanf(filepath,'%s',1);
        temp=fscanf(filepath,'%s',1);
        TempA=[temp(1:2) temp(4:5)];
        Slice.TP=str2num(TempA);
    end
end
fclose(filepath);
else
    disp([path1 'not found']);
end


disp(['Time costing for parameter abstracting: ' num2str((cputime-TIME)) ' s...']);
y=Slice;
end

function y=W_strcmp(strA,strB)
% By Zhiliang Wei 08-19-2016, Johns Hopkins University
% strA can differ in size from strB, return 1 when strA or strB is
% consistent with a fraction of the other
scale=min([prod(size(strA)) prod(size(strB))]);
if scale==0
    y=0;
else
    if sum(abs(strA(1:scale)-strB(1:scale)))==0
        y=1;
    else
        y=0;
    end
end
end

    

