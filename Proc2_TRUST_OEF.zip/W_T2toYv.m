function Yv=W_T2toYv(T2,choice)
% Return the venous oxygenation saturation
Yv=zeros(size(T2));
for ni=1:prod(size(T2))
    if choice==1
        Ref=load('Calibration.txt');
    else
        Ref=load('CalibrationLi.txt');
    end
Temp=(Ref(:,1)-T2(ni)).^2;
Pos=find(Temp==min(Temp));
Yv(ni)=Ref(fix(mean(Pos)),2);
end
end