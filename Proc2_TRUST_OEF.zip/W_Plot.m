function W_Plot
set(gca,'linewidth',3);
set(gca,'box','off');
set(gca,'tickdir','out');
set(gca,'fontsize',16);
end

