function W_MaskShow(Img,Mask,choice,range)
% Showing the image with mask trace
% By Zhiliang Wei, Mar. 7, 2017
if choice==1
    imshow(Img,range,'initialmagnification','fit');
    colorbar;
else
    imagesc(Img);colormap(jet);colorbar;
end
hold on;
Temp=W_Trace(Mask);
[TempY TempX]=find(Temp);
plot(TempX,TempY,'r.');
title('Image with mask trace');
end