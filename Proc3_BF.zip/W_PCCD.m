function y=W_PCCD(filepath,choice)
% Reconstructing the phase-contrast based velocity map along with complex
% difference image
% By Zhiliang Wei, Apr. 6, 2018

% toolbox with readin functions
Result = readbrukerdata(filepath);
% Data format in the kspace:
% 5D: frequency encoding x phase encoding x channel number x frame number x
% repetition number

% Partial Fourier 
scale=size(Result.kspace);
if scale(1)>scale(2)   % PF along the 2nd dim.
    tempspace=zeros([scale(1) scale(1) scale(3:end)]);
    temp=abs(sum(Result.kspace(:,:,1)));
    pos=find(temp==max(temp));
    if pos<0.5*scale(2)
        tempspace(:,scale(1)-scale(2)+1:scale(1),:,:,:)=Result.kspace;
    else
        tempspace(:,1:scale(2),:,:,:)=Result.kspace;
    end  
elseif scale(1)<scale(2)  % PF along the 1st dim.
    tempspace=zeros([scale(2) scale(2) scale(3:end)]);
    temp=abs(sum(Result.kspace(:,:,1).'));
    pos=find(temp==max(temp));
    if pos<0.5*scale(1)
        tempspace(scale(2)-scale(1)+1:scale(2),:,:,:,:)=Result.kspace;
    else
        tempspace(1:scale(1),:,:,:,:)=Result.kspace;
    end
else
    ;
end
Result.kspace=tempspace;
scale=size(Result.kspace);

% Calculate M1 and M2 (+/- velocity encoding; -/+ velocity encoding)
% M1 part:
tempM1=zeros([scale(1:2) 0.5*scale(4) scale(5)]);
for pi=1:scale(5)
    for qi=1:0.5*scale(4)
        tempI=zeros(scale(1:2));
        for ni=1:scale(3)
            temp=Result.kspace(:,:,ni,2*qi-1,pi);
            tempf=abs(fftshift(fft2(fftshift(temp))));
            tempI=tempI+tempf.^2;
        end
        tempM1(:,:,qi,pi)=fliplr(flipud(sqrt(tempI.')));
    end
end
if choice~=0
    figure;imshow(abs(tempM1(:,:,1)),[]);title('M1');
end
% M2 part:
tempM2=zeros([scale(1:2) 0.5*scale(4) scale(5)]);
for pi=1:scale(5)
    for qi=1:0.5*scale(4)
        tempI=zeros(scale(1:2));
        for ni=1:scale(3)
            temp=Result.kspace(:,:,ni,2*qi,pi);
            tempf=abs(fftshift(fft2(fftshift(temp))));
            tempI=tempI+tempf.^2;
        end
        tempM2(:,:,qi,pi)=fliplr(flipud(sqrt(tempI.')));
    end
end
if choice~=0
    figure;imshow(abs(tempM2(:,:,1)),[]);title('M2');
end

% Phase difference for velocity map
pha=zeros([scale(1:2) 0.5*scale(4) scale(5)]);
for pi=1:scale(5)
    for qi=1:0.5*scale(4)
        tempA=zeros(scale(1:2));
        for ni=1:scale(3)
            tempB=fftshift(fft2(fftshift(Result.kspace(:,:,ni,2*qi-1,pi))));
            tempC=fftshift(fft2(fftshift(Result.kspace(:,:,ni,2*qi,pi))));
            tempA=tempA+tempB.*conj(tempC);
        end
        pha(:,:,qi,pi)=fliplr(flipud(angle(tempA.')));
    end
end

if choice~=0
    figure;imshow(circshift(pha(:,:,1),[0 0]),[]);title('Velocity Map');
end

% Complex difference
CD=zeros([scale(1:2) 0.5*scale(4) scale(5)]);
for pi=1:scale(5)
    for qi=1:0.5*scale(4)
        CD(:,:,qi,pi)=tempM1(:,:,qi,pi).^2+tempM2(:,:,qi,pi).^2-2.*tempM1(:,:,qi,pi).*tempM2(:,:,qi,pi).*cos(pha(:,:,qi,pi));
    end
end
CD=(sqrt(CD));

if choice~=0
    figure;imshow(CD(:,:,1),[]);
end
% Return the result
y.M1=tempM1;
y.M2=tempM2;
y.pha=pha;
y.CD=CD;

end

