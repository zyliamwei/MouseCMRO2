function y=W_FindPC(filepath)
% This script is for finding SPIL dataset for further processing 
% processing, Dec. 14th, 2017
% Modified, Aug. 6th, 2018
expno=W_Expno(filepath)
Rec=[];
for ni=1:length(expno)
    tempno=expno(ni);
    filename=[filepath filesep num2str(tempno)];
    Para=W_ImgParaAbs(filename);
    if (W_SubStr('PC',Para.Protocol))||(W_SubStr('FLOWMAP',Para.Protocol))
        Rec=[Rec tempno];
    end
end
y=Rec;
end
        