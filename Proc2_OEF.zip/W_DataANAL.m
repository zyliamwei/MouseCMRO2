function y=W_DataANAL(Para)
% Analyze the batch-wise data
% Cited from previous codes for GUI
% Read the most recent result
OrigPath=Para.AnalPath;
path=[OrigPath filesep 'Reports.txt'];
if exist(path)
data=load(path);
if Para.ParVar==1
    XPara='Scan dependence';
elseif Para.ParVar==2
    XPara='Post labeling time (ms) dependence';
elseif Para.ParVar==3
    XPara='CPMG echo time (ms) dependence';
else
    XPara=[];
end

HS=[];
% Set the abscissa
X1=min(data(1,:));
X2=max(data(1,:))+1e-6;
% Labeling efficiency
HT=figure;HS=[HS HT];
subplot(1,3,1);
plot(data(1,:),data(2,:),'ro-');title('Labeling efficiency');
axis([X1 X2 0 100]);xlabel(XPara);grid on;
% Difference and control intensities
TempS=fix(0.5*(size(data,1)-6))-1;
subplot(1,3,2);plot(data(1,:),data(5:5+TempS,:),'o-');title('Difference intensity');
axis([X1 X2 0 25]);xlabel(XPara);grid on;
subplot(1,3,3);plot(data(1,:),data(6+TempS:6+TempS*2,:),'o-');title('Control intensity');
axis([X1 X2 0 25]);xlabel(XPara);grid on;

% T2 of blood & tissue
HT=figure;HS=[HS HT];
subplot(1,2,1);
plot(data(1,:),data(3,:),'ro-');title('T2 of blood & tissue');
axis([X1 X2 0 60]);xlabel(XPara);grid on;
hold on;plot(data(1,:),data(4,:),'bsquare-');
axis([X1 X2 0 60]);xlabel(XPara);grid on;
legend('Blood','Tissue');
subplot(1,2,2);hold on;
plot(data(1,:),data(7+2*TempS,:),'ro-');title(['Confidence' ' \DeltaR2']);
plot(data(1,:),data(8+2*TempS,:),'bsquare-');grid on;
legend('Blood','Tissue');xlabel(XPara);

% Save the results
Para.WinH=[Para.WinH HS];
saveas(HS(1),[OrigPath filesep 'R1_Distribution'],'fig');
saveas(HS(1),[OrigPath filesep 'R1_Distribution'],'tif');
saveas(HS(2),[OrigPath filesep 'R2_T2'],'fig');
saveas(HS(2),[OrigPath filesep 'R2_T2'],'tif');
else
    errordlg('Result file loss in the directory');
end
y=Para;
end
    