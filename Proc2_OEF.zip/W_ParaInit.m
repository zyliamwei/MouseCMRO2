function y=W_ParaInit(path)
% Initialize the parameters
ParaTemp=load(path);
Para.Rec=ParaTemp(1);
Para.MaskNum=ParaTemp(2);     % number of points for average when determining vein
Para.Balance=ParaTemp(3);
Para.DisRange=ParaTemp(4:5);  % Range for display the image;
Para.ROI=ParaTemp(6);
Para.font=ParaTemp(7);
Para.ROISave=ParaTemp(8);
Para.GroupNum=ParaTemp(9);
Para.StatNum=ParaTemp(10);
Para.IMGw=ParaTemp(11:13);
Para.ParVar=ParaTemp(14);      % Parameter varied among batch-wise experiments

Para.NCExpno=[];    % expno not converted (Shimming map)
Para.TRExpno=[];    % TRUST expno
Para.ProcNum=[0];    % expno to be processed 
Para.GMSig=[];      % Matrix to store the original signal
Para.GMMask=[];     % Matrix to store the mask 
Para.HisInfor=['History review ...'];
Para.WinH=[];       % handles for all the processing windows
Para.TabStr={'Unknown','Label Eff','Blood T2','Yv','OEF','Tissue T2',...
    'DIF Amp1','DIF Amp2','DIF Amp3','Con Amp1','Con Amp2','Con Amp3',...
    'Blood D-T2','Tissue D-T2'};
Para.CMD=[];
Para.FigCorr=0;
% initial the filepath
fp=fopen('W_Filepath.txt','r');
Para.ReadPath=fscanf(fp,'%s',1);
fclose(fp);

ScanListTemp=[Para.ReadPath filesep 'ScanListTRUST.txt'];
if exist(ScanListTemp)
    Para.TRExpno=load(ScanListTemp);
    Para.ProcNum=Para.TRExpno;
end
ScanListTemp=[Para.ReadPath filesep 'ScanList.txt'];
if exist(ScanListTemp)
    open(ScanListTemp);
end
    
fp=fopen('W_Settings.txt','r');
Para.AnalPath=fscanf(fp,'%s',1);
fclose(fp);

if prod(size((Para.AnalPath)))<2
    Para.GSave=[];
else
    if exist([Para.AnalPath filesep 'Reports.txt'])
        Para.GSave=load([Para.AnalPath filesep 'Reports.txt']);
    else
        Para.GSave=[];
    end
end

if length(Para.TRExpno)
    Para.ProcNum=Para.TRExpno;
end

y=Para;
end