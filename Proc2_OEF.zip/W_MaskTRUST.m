function [TrustROI1 TrustROI2]=W_MaskTRUST(Imag,PSave)
% Return the ROI mask for extracting sagittal sinus
addpath('MaskGenerator');
OrigMask=W_PRMaskExt(Imag);
% Locate the sagittal sinus from a global view
OrigMaskVec=max(OrigMask.');
Pos=find(OrigMaskVec);
MaskFilter=zeros(size(OrigMask));
% Retain the upper region with high SNR
MaskFilter(Pos(1):fix(Pos(1)+(Pos(end)-Pos(1))*0.33),:)=1;
OrigMaskF=MaskFilter.*OrigMask;
% Fill the sagittal sinus and retain after subtraction
OrigMaskF=imerode(imdilate(OrigMaskF,strel('disk',10)),strel('disk',10))-OrigMaskF;
OrigMaskF=imdilate(OrigMaskF,strel('disk',3));
TrustROI1=OrigMaskF;
TrustROI2=OrigMask;
% Tailor the tissue ROI
while sum(sum(TrustROI2))>20
    TrustROI2=imerode(TrustROI2,strel('line',2,0));
    TrustROI2=imerode(TrustROI2,strel('line',2,90));
end
TrustROI2=imdilate(TrustROI2,strel('square',5));
H=figure('visible','off');
GrayColorFusion(Imag,Imag,TrustROI1,colormap(jet),[]);
saveas(H,[PSave filesep 'ROI_CSS'],'tif');
saveas(H,[PSave filesep 'ROI_CSS'],'eps');
close(H);
H=figure('visible','off');GrayColorFusion(Imag,Imag,TrustROI2,colormap(jet),[]);
saveas(H,[PSave filesep 'ROI_TIS'],'tif');
saveas(H,[PSave filesep 'ROI_TIS'],'eps');
close(H);
end