function y=W_TabStr(Para)
% Return the Tab column name
Para.TabStr=[];
if Para.ParVar==1
    Para.TabStr{1}='Scan';
elseif Para.ParVar==2
    Para.TabStr{1}='Post Label Time';
elseif Para.ParVar==3
    Para.TabStr{1}='CPMG echo time';
else
    Para.TabStr{1}='Invalid';
end
Para.TabStr{2}='Label Eff';
Para.TabStr{3}='Blood T2';
Para.TabStr{4}='Yv';
Para.TabStr{5}='OEF';
Para.TabStr{6}='Tissue T2';
scale=size(Para.GSave,1);
TempS=fix(0.5*(scale-8));
for ni=1:TempS
    Para.TabStr{6+ni}=['DIF Amp' num2str(ni)];
end
for ni=1:TempS
    Para.TabStr{6+TempS+ni}=['CON Amp' num2str(ni)];
end
Para.TabStr{7+2*TempS}='Blood D-T2';
Para.TabStr{8+2*TempS}='Tissue D-T2';
y=Para;
end