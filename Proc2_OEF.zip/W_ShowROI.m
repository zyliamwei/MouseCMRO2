function y=W_ShowROI(data,mask,Para)
% display the image with ROI shown in red
MaxT=max(max(data));
dataT=(data.*(~mask))+1.2*MaxT*mask;
CMap=gray(64);
CMap(64,2:3)=0;
imshow(dataT,Para.DisRange);colormap(CMap);
end
