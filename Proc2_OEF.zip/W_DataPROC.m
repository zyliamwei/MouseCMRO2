function y=W_DataPROC(Para)
% processing the TRUST data
% Cited from previous code Step 2 for GUI
% By Zhiliang Wei, August 12, 2016, The Johns Hopkins University
% Add toolbox
addpath('toolbox');
% Load the filepath
addpath('LinPlot');
OrigDir=Para.ReadPath;
[OrigDirA OrigDirB]=fileparts(OrigDir);

% Parameteric initions
expno = Para.ProcNum;
MaskNum = Para.MaskNum;

GDiffAmp=[]; 
GConAmp=[];
GLabEff=[];
GBeT2=[];
GTeT2=[];
GPara=[];
GDBeR2=[];
GDTeR2=[];

% Save pilot process
ProcOrder=load('W_Para.txt');
PSave=['Results' filesep 'N' num2str(ProcOrder(1)) '_' OrigDirB '_' num2str(expno(1)) '_' num2str(expno(end))];
if ~exist(PSave)
    mkdir(PSave);
end
ProcOrder(1)=ProcOrder(1)+1;
dlmwrite('W_Para.txt',ProcOrder);

GMSig=[]
GMMask=[];

for ni=1:prod(size(expno))
    
    BaseDir = [OrigDir filesep 'Analyses' filesep num2str(expno(ni))];
    TrustName = 'TRUST_IMG';
    
    % Parameter extraction
    filename=[OrigDir filesep num2str(expno(ni))];
    ParaExp=W_ImgParaAbs(filename);
    % Distributing parameters
    NRow = ParaExp.size(2);
    NCol = ParaExp.size(1);
    eTE  = ParaExp.eTE;
    NumTE=length(eTE);
    DynNum=ParaExp.NR/NumTE;
    ResRow=ParaExp.ROI(1)/ParaExp.size(1);
    ResCol=ParaExp.ROI(2)/ParaExp.size(2);
    ResSlice=ParaExp.thickness;

    %% Splitting data files to subsets
    RawImag=loadimage([BaseDir filesep 'IMG.img'],1);
    for m = 1:NumTE
        for n = 1:DynNum
            TempStr = ['00' num2str(n)];
            TempStr = TempStr(end-2:end);     
            % Exporting the subsets
            eTEDir=[BaseDir filesep TrustName '_' num2str(fix(eTE(m)))];
            if ~exist(eTEDir)
                mkdir(eTEDir);  
            end
            write_ANALYZE(RawImag(:,:,(m-1)*DynNum+n),[eTEDir filesep 'IMG_' TempStr '.img'],...
                [NRow NCol 1], [ResRow ResCol ResSlice], 1,16);
        end
        % Assuming that motion is not severe due to anesthetization
    end

    eTE = sort(eTE);
    Imag=zeros(NRow,NCol,NumTE,DynNum);
    for m=1:NumTE
        for n=1:DynNum
            TempStr = ['00' num2str(n)];
            TempStr = TempStr(end-2:end);   
            eTEDir=[BaseDir filesep TrustName '_' num2str(fix(eTE(m))) filesep 'IMG_' TempStr '.img'];
            Imag(:,:,m,n)=loadimage(eTEDir,1);
        end
    end
    

    % Constructing TRUST data
    ImagLab=Imag(:,:,:,1:2:DynNum);
    ImagCon=Imag(:,:,:,2:2:DynNum);   
    
%     if Para.FigCorr==1
%         ImagLab(:,:,end)=circshift(ImagLab(:,:,end),[-fix(0.5*size(ImagLab,2)) 0]);
%         ImagCon(:,:,end)=circshift(ImagCon(:,:,end),[-fix(0.5*size(ImagCon,2)) 0]);
%     end
    if Para.FigCorr==1
        for kk=3
            ImagLab(:,:,kk)=0.5*(ImagLab(:,:,kk)+circshift(ImagLab(:,:,kk),[-fix(0.5*size(ImagLab,2)) 0]));
            ImagCon(:,:,kk)=0.5*(ImagCon(:,:,kk)+circshift(ImagCon(:,:,kk),[-fix(0.5*size(ImagLab,2)) 0]));
            disp('EPI correction');
        end
    end
    
    ImagDiff=ImagCon-ImagLab;

    AveDiff=mean(ImagDiff,4);
    AveCon=mean(ImagCon,4);
    AveLab=mean(ImagLab,4);

    write_ANALYZE(reshape(ImagDiff,NRow,NCol,NumTE*DynNum/2),[BaseDir filesep ...
        'TRUST_DIFF.img'],[NRow NCol NumTE*DynNum/2],[ResRow ResCol ResSlice],1,16);

    %% Drawing ROI and performing fitting
    ROI=AveDiff(:,:,1);  
    PROC_H=figure;
    if ni==1
        if (Para.ROI>0)&&(exist(['Z_MaskA' num2str(Para.ROI) '.txt']))
           MaskTA=load(['Z_MaskA' num2str(Para.ROI) '.txt']);
        elseif Para.ROI==-1
           [MaskTA MaskB]=W_MaskTRUST(ImagLab(:,:,1),PSave);
        else
            imshow(ROI,Para.DisRange,'initialmagnification','fit');
            MaskTA=roipoly;
%             MaskTA=roipoly(ROI/10); 
            if Para.ROISave==1
                dlmwrite(['Z_MaskA' num2str(Para.Rec) '.txt'],MaskTA);
            end               
        end
    end
    close(PROC_H);
    MaskTemp=MaskTA.*ROI;
    MaskTemp=sort(MaskTemp(:),'descend');
    if MaskNum<length(MaskTemp)
        MaskA=MaskTA.*(ROI>MaskTemp(MaskNum+1));
    else
        MaskA=MaskTA;
    end
    if ni==1
        display_fmri(ROI,MaskA);
        if Para.ROISave==1
            saveas(gca,['Z_MaskA' num2str(Para.Rec)],'tif');
        end
    end

    ROI=AveCon(:,:,1);  
    PROC_H=figure;
    if ni==1
        if (Para.ROI>0)&&(exist(['Z_MaskB' num2str(Para.ROI) '.txt']))
           MaskB=load(['Z_MaskB' num2str(Para.ROI) '.txt']);
        elseif Para.ROI==-1
            ;
        else
            imshow(ROI,Para.DisRange,'initialmagnification','fit');
            MaskB=roipoly;
%             MaskB=roipoly(ROI/10);
            if Para.ROISave==1
                dlmwrite(['Z_MaskB' num2str(Para.Rec) '.txt'],MaskB);
            end           
        end
    end
    close(PROC_H);
    if ni==1
        display_fmri(ROI,MaskB); 
        if Para.ROISave==1
            saveas(gca,['Z_MaskB' num2str(Para.Rec)],'tif');
        end
    end

    % Save the whole matrix to be displayed later
    GMTemp1=[];GMTemp2=[];
    for mi=1:NumTE
        if length(Para.IMGw)<NumTE
            GMTemp1=[GMTemp1 AveCon(:,:,mi)];
        else
            GMTemp1=[GMTemp1 Para.IMGw(mi).*AveCon(:,:,mi)];
        end
        GMTemp2=[GMTemp2 MaskB];
    end
    for mi=1:NumTE
        if length(Para.IMGw)<NumTE
            GMTemp1=[GMTemp1 Para.Balance*AveDiff(:,:,mi)];
        else
            GMTemp1=[GMTemp1 Para.IMGw(mi).*Para.Balance*AveDiff(:,:,mi)];
        end
            GMTemp2=[GMTemp2 MaskA];
    end
    GMSig=[GMSig;GMTemp1;];
    GMMask=[GMMask;GMTemp2;];
    
    % Fitting procedure
    eTE=eTE.';
    BloodT1=2800;
    TissueT1=1800;
    TI=1000;

    % Construct the eTE list
    ListTE=ones(DynNum/2,1)*eTE.';
    ListTE=ListTE(:);

    % Construct the Amplitude lists of both difference and control groups
    ListDiffAmp=zeros(DynNum/2,NumTE);
    ListConAmp=zeros(DynNum/2,NumTE);
    ListConAmpB=zeros(DynNum/2,NumTE);
    for m=1:NumTE
        TempA = reshape(ImagDiff(:,:,m,:),NRow,NCol,DynNum/2);
        TempB = average_actpixel(1,MaskA,TempA);close;
        ListDiffAmp(:,m)=TempB(:);

        TempA = reshape(ImagCon(:,:,m,:),NRow,NCol,DynNum/2);
        TempB = average_actpixel(1,MaskB,TempA);close;
        ListConAmp(:,m)=TempB(:); 
        
        TempA = reshape(ImagCon(:,:,m,:),NRow,NCol,DynNum/2);
        TempB = average_actpixel(1,MaskA,TempA);close;
        ListConAmpB(:,m)=TempB(:); 
    end

    ListDiffAmpV=reshape(ListDiffAmp.',DynNum/2*NumTE,1);
    ListConAmpV=reshape(ListConAmp.',DynNum/2*NumTE,1);
    ListConAmpVB=reshape(ListConAmpB.',DynNum/2*NumTE,1);    
    % Performing T1 correction
    for m=1:DynNum/2
        for n=1:NumTE-1
            % Difference group
            ListDiffAmpV((m-1)*NumTE+n)=exp(-(TI-eTE(NumTE))/BloodT1)/...
                exp(-(TI-eTE(n))/BloodT1)*ListDiffAmpV((m-1)*NumTE+n);
            % Control group
            ListConAmpV((m-1)*NumTE+n)=exp(-(TI-eTE(NumTE))/BloodT1)/...
                exp(-(TI-eTE(n))/BloodT1)*ListConAmpV((m-1)*NumTE+n);  
            
            % Control group with mask as difference group
%             ListConAmpVB((m-1)*NumTE+n)=exp(-(TI-eTE(NumTE))/BloodT1)/...
%                 exp(-(TI-eTE(n))/BloodT1)*ListConAmpVB((m-1)*NumTE+n);    
               ListConAmpVB((m-1)*NumTE+n)=(1-exp(-1000./TissueT1)*exp(eTE(NumTE)/TissueT1))/...
                   (1-exp(-1000./TissueT1)*exp(eTE(n)/TissueT1))*ListConAmpVB((m-1)*NumTE+n); 
        end
    end   
    
    Proc_H=figure;
    subplot(1,2,1);
    FitTemp=W_MonoExpFitting(ListTE,ListDiffAmpV,eTE,...
        [num2str(expno(ni)) ' Diff Group']);
    GBeT2=[GBeT2 FitTemp(1)];
    GDBeR2=[GDBeR2 FitTemp(2)];

    subplot(1,2,2);
    FitTemp=W_MonoExpFitting(ListTE,ListConAmpV,eTE,...
        [num2str(expno(ni)) ' Cont Group']);
    GTeT2=[GTeT2 FitTemp(1)];
    GDTeR2=[GDTeR2 FitTemp(2)];
    saveas(Proc_H,[PSave filesep 'Fitting_' num2str(expno(ni))],'fig');
    saveas(Proc_H,[PSave filesep 'Fitting_' num2str(expno(ni))],'tif');
    Para.WinH=[Para.WinH Proc_H];
    
    %% Calculating the labelling efficiency
    LabEff=mean(ListDiffAmp(:,1))/mean(ListConAmpB(:,1))*100;
    ParaExp.LabelEfficiency=W_DigitS(LabEff,2);
    
    % Exporting the statistical results in a group
    GDiffAmp=[GDiffAmp ListDiffAmpV];
    GConAmp=[GConAmp ListConAmpV];
    GLabEff=[GLabEff LabEff];
    if Para.ParVar==1
        GPara=[GPara expno(ni)];
    elseif Para.ParVar==2
        GPara=[GPara ParaExp.PostLabelTime];
    elseif Para.ParVar==3
        GPara=[GPara ParaExp.eTE(3)./ParaExp.EchoNum(3)];
    else
        GPara=[];
    end
    % Write parameters
    W_ParaWrite(PSave,ParaExp,1);
end

% Save the original data
save([PSave filesep 'IMGCon.mat'],'ImagCon');
save([PSave filesep 'IMGLab.mat'],'ImagLab');
save([PSave filesep 'IMGDiff.mat'],'ImagDiff');

Proc_H=figure;W_ShowROI(GMSig,GMMask,Para);
saveas(Proc_H,[PSave filesep 'ROI_' num2str(expno(ni))],'fig');
saveas(Proc_H,[PSave filesep 'ROI_' num2str(expno(ni))],'tif');
Para.WinH=[Para.WinH Proc_H];
Para.GMSig=GMSig;
Para.GMMask=GMMask;
% Store the results
GBYv=W_T2toYv(GBeT2,2);
GBOEF=99-GBYv;
GSave=[GPara;GLabEff;GBeT2;GBYv;GBOEF;GTeT2;GDiffAmp;GConAmp;GDBeR2;GDTeR2;];
dlmwrite([PSave filesep 'Reports.txt'],GSave);
xlswrite([PSave filesep 'Reports.xls'],GSave);
fp=fopen('W_Settings.txt','w');
fprintf(fp,'%s',PSave);
fclose(fp);
% return the Para
Para.AnalPath=PSave;
Para.GSave=GSave
y=Para;
end
