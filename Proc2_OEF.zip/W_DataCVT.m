function y=W_DataCVT(Para)
% Coverting the data for analyzing convenience
% Cite the original Step 1 here for GUI
% By Zhiliang Wei, August 12, 2016, Departemtn of Radiology, The Johns
% Hopkins University
% Add toolbox
addpath('toolbox');
addpath('HeartBeat');
addpath('toolboxHB');
filepath=Para.ReadPath;
if Para.ProcNum==0
    expno=W_Expno(filepath)
else
    expno=Para.ProcNum;
end
NCExpno=[];
TRExpno=[];
UTExpno=[];
% Store the filepath
fp=fopen('W_Filepath.txt','w');
fprintf(fp,'%s',filepath);
fclose(fp);
% Support batch-wise processing
Scale=max(size(expno));
if Scale>1
    ProgressH=waitbar(0,'TRUST data exporting ...');
end

if exist([Para.ReadPath filesep 'Analyses'])
    rmdir([Para.ReadPath filesep 'Analyses'],'s');
end
for ExpCont=1:Scale
    % Parameter extractions
    filename=[filepath filesep num2str(expno(ExpCont))];
    ParaExp=W_ImgParaAbs(filename);
    % Suggest TRUST data
    if W_SubStr(ParaExp.Protocol,'trust')
        TRExpno=[TRExpno expno(ExpCont)];
    end
    if W_SubStr(ParaExp.Protocol,'UTE')
        UTExpno=[UTExpno expno(ExpCont)];
    end
    
    reconname=[filepath filesep num2str(expno(ExpCont)) filesep 'pdata' ...
        filesep num2str(1) filesep 'reco'];
    imagname=[filepath filesep num2str(expno(ExpCont)) filesep 'pdata' ...
        filesep num2str(1) filesep '2dseq'];
    
    if exist(reconname)&&exist(imagname)
%     if (W_SubStr(ParaExp.Protocol,'shim')~=1)&&...
%             (W_SubStr(ParaExp.Protocol,'STEAM')~=1)&&...
%             (W_SubStr(ParaExp.Protocol,'PRESS')~=1)&&...
%             (W_SubStr(ParaExp.Protocol,'B0Map')~=1)
        if  (W_SubStr(ParaExp.Protocol,'STEAM')~=1)&&...
            (W_SubStr(ParaExp.Protocol,'PRESS')~=1)&&...
            (W_SubStr(ParaExp.Protocol,'B0Map')~=1)
    % Directory to export data
    exportdir=[filepath filesep 'Analyses' filesep num2str(expno(ExpCont))];
    if ~exist(exportdir)
    mkdir(exportdir);
    end

    % Exporting data
     expno(ExpCont)
    [Image NX NY NI]=read_2dseq_v3(filepath,expno(ExpCont),1);
    Image=squeeze(Image);
    ImageSize=size(Image);
%     Image=flipdim(Image,1);
%     if length(ImageSize)==3
%         Image=permute(Image,[2 1 3]);
%     end
    % [Data ExportPath MatrixSize Resolution Scaling DataType]
    if (prod(ImageSize)./(ImageSize(1)*ImageSize(2)))==(ParaExp.slicenum.*ParaExp.NR)
        Image=reshape(Image,NX,NY,ParaExp.slicenum.*ParaExp.NR);
        write_ANALYZE(Image,[exportdir filesep 'IMG.img'],[ParaExp.size ...
            ParaExp.slicenum.*ParaExp.NR],[ParaExp.ROI./ParaExp.size ParaExp.thickness],1,16);   
        % Write parameters
        W_ParaWrite(exportdir,ParaExp,1);
    else
        NCExpno=[NCExpno expno(ExpCont)];
    end
    end
    
    end
    List(ExpCont).Num=expno(ExpCont);
    List(ExpCont).Protocol=ParaExp.Protocol;
    List(ExpCont).Scan=ParaExp.Scan; 
    
    % Show the progress bar
    if Scale>1
        if ishandle(ProgressH)
            waitbar(ExpCont/Scale,ProgressH,['Data exporting ... ' ...
                num2str(ExpCont) '/' num2str(Scale)]);
        end
    end
end
% Show the expno not converted
if prod(size(NCExpno))>0
    ErrorH=errordlg(['Expno-' num2str(NCExpno) ' not converted ...']);
    pause(1);
    if ishandle(ErrorH)
        close(ErrorH);
    end
end
% Close the progress bar
if Scale>1
    if ishandle(ProgressH)
        close(ProgressH);
    end
end
Para.NCExpno=NCExpno;
Para.TRExpno=TRExpno;
% Record the Scan list
if exist([filepath filesep 'ScanList.txt'])
    delete([filepath filesep 'ScanList.txt']);
end
fp=fopen([filepath filesep 'ScanList.txt'],'w');
fprintf(fp,'%s',[filepath 10 10]);
for ni=1:length(List)
    fprintf(fp,'%s',['Exp# ' num2str(List(ni).Num) ' ' 'Protocol: ' ...
        List(ni).Protocol ' ' 'Scan Name: ' ...
        List(ni).Scan 10]);
end
fclose(fp);
open([filepath filesep 'ScanList.txt']);
% Record the TRUST list
if exist([filepath filesep 'ScanListTRUST.txt'])
    delete([filepath filesep 'ScanListTRUST.txt']);
end
fp=fopen([filepath filesep 'ScanListTRUST.txt'],'w');
fprintf(fp,'%s',num2str(TRExpno));
fclose(fp);
% Record the UTE list
if exist([filepath filesep 'ScanListUTE.txt'])
    delete([filepath filesep 'ScanListUTE.txt']);
end
fp=fopen([filepath filesep 'ScanListUTE.txt'],'w');
fprintf(fp,'%s',num2str(UTExpno));
fclose(fp);
filepath
UTExpno
Para.ProcNum=Para.TRExpno;
y=Para;
end


