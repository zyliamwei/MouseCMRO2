function Trace=W_Trace(Mat)
% Yielding the contour of the image
Trace=(abs(Mat-circshift(Mat,[-1 0])))+...
    (abs(Mat-circshift(Mat,[1 0])))+...
    (abs(Mat-circshift(Mat,[0 -1])))+...
    (abs(Mat-circshift(Mat,[0 1])));
Trace=Trace>0;
Trace=W_FillMask(Trace);
Trace=Trace-Mat;
end
