function y=W_PCCD(filepath,choice)
% Reconstructing the phase-contrast based velocity map along with complex
% difference image
% By Zhiliang Wei, Apr. 6, 2018
% Modified by Zhiliang Wei, Apr. 10, 2018 for spatial folding study

% toolbox with readin functions
addpath('toolbox');
Result = readbrukerdata(filepath);
% Data format in the kspace:
% 5D: frequency encoding x phase encoding x channel number x frame number x
% repetition number

% Partial Fourier 
scale=size(Result.kspace);
tempspace=zeros([300 200 scale(3:end)]);
for mi=1:scale(3)
    for ni=1:scale(4)
        for qi=1:scale(5)
            tempspace(94:300,:,mi,ni,qi)=Result.kspace(:,:,mi,ni,qi);
            tempspace(1:93,:,mi,ni,qi)=fliplr(flipud(Result.kspace(115:207,:,mi,ni,qi)));
        end
    end
end

Result.kspace=tempspace;
figure;subplot(2,2,1);imshow(Result.kspace(:,:,1,1),[]);
subplot(2,2,2);imshow(Result.kspace(:,:,2,1),[]);
subplot(2,2,3);imshow(Result.kspace(:,:,3,1),[]);
subplot(2,2,4);imshow(Result.kspace(:,:,4,1),[]);
scale=size(Result.kspace);


% Calculate M1 and M2 (+/- velocity encoding; -/+ velocity encoding)
% M1 part:
tempM1=zeros([scale(1:2) 0.5*scale(4) scale(5)]);
for pi=1:scale(5)
    for qi=1:0.5*scale(4)
        tempI=zeros(scale(1:2));
        for ni=1:scale(3)
            temp=Result.kspace(:,:,ni,2*qi-1,pi);
            tempf=abs(ifftshift(fft2(fftshift(temp))));
            tempI=tempI+tempf.^2;
        end
        tempM1(:,:,qi,pi)=((sqrt(tempI)));
    end
end
if choice~=0
    figure;imshow(abs(tempM1(:,:,1)),[]);title('M1');
end
% M2 part:
tempM2=zeros([scale(1:2) 0.5*scale(4) scale(5)]);
for pi=1:scale(5)
    for qi=1:0.5*scale(4)
        tempI=zeros(scale(1:2));
        for ni=1:scale(3)
            temp=Result.kspace(:,:,ni,2*qi,pi);
            tempf=abs(ifftshift(fft2(fftshift(temp))));
            tempI=tempI+tempf.^2;
        end
        tempM2(:,:,qi,pi)=((sqrt(tempI)));
    end
end
if choice~=0
    figure;imshow(abs(tempM2(:,:,1)),[]);title('M2');
end

% Phase difference for velocity map
pha=zeros([scale(1:2) 0.5*scale(4) scale(5)]);
for pi=1:scale(5)
    for qi=1:0.5*scale(4)
        tempA=zeros(scale(1:2));
        for ni=1:scale(3)
            tempB=ifftshift(fft2(fftshift(Result.kspace(:,:,ni,2*qi-1,pi))));
            tempC=ifftshift(fft2(fftshift(Result.kspace(:,:,ni,2*qi,pi))));
            tempA=tempA+tempB.*conj(tempC);
        end
        pha(:,:,qi,pi)=((angle(tempA)));
    end
end

if choice~=0
    figure;imshow(circshift(pha(:,:,1),[0 0]),[]);title('Velocity Map');
end

% Complex difference
CD=zeros([scale(1:2) 0.5*scale(4) scale(5)]);
for pi=1:scale(5)
    for qi=1:0.5*scale(4)
        CD(:,:,qi,pi)=tempM1(:,:,qi,pi).^2+tempM2(:,:,qi,pi).^2-2.*tempM1(:,:,qi,pi).*tempM2(:,:,qi,pi).*cos(pha(:,:,qi,pi));
    end
end
CD=(sqrt(CD));

if choice~=0
    figure;imshow(CD(:,:,1),[]);
end
% Return the result
y.M1=tempM1;
y.M2=tempM2;
y.pha=pha;
y.CD=CD;

end

