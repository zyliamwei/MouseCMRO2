function y=W_DigitS(data,num)
% to return a value with certain digit 
data=data*10^num;
data=floor(data);
data=data/10^num;
y=num2str(data);
end
