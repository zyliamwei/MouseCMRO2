function y=W_PCproc(Para)
% Calculate the BF for PC MRI
Temp=mean(mean(Para.ArtROI.CD,4),3);
ArtMask=roipoly(Temp(min(Para.ZoomPos(:,2)):max(Para.ZoomPos(:,2)),min(Para.ZoomPos(:,1)):max(Para.ZoomPos(:,1))),Para.ROImat(:,1),Para.ROImat(:,2));
Image=Para.Vel(min(Para.ZoomPos(:,2)):max(Para.ZoomPos(:,2)),min(Para.ZoomPos(:,1)):max(Para.ZoomPos(:,1)),:);
ImageSize=size(Image);
for ni=1:ImageSize(3)    
    se1=strel('line',2,0);
    se2=strel('line',2,90);
    ArtMaskTemp=imerode(ArtMask,se1);
    ArtMaskTemp=imerode(ArtMaskTemp,se2);
    TempCorr=((Image(:,:,ni).*ArtMaskTemp)<0)*2*Para.para.VENC;
    if sum(sum(TempCorr))
        Image(:,:,ni)=Image(:,:,ni)+TempCorr;   
    end
end 
figure;subplot(2,2,[1 2]);temp=W_MSplot(Image,[1 2],0,[]);
imagesc(temp,[-Para.para.VENC Para.para.VENC]);
title(['Corrected Repetition: ']);
% Calculate the blood flow
ImageAve=mean(Image,3);
ArtMask=ArtMask.*(ImageAve>0);

subplot(2,2,[3 4]);
temp=ImageAve.*(ArtMask+0.1*ones(size(ArtMask)));
imagesc([temp temp],[-Para.para.VENC Para.para.VENC]);
saveas(gcf,[Para.SavePath filesep 'ROI' num2str(ni) '.tif']);
% Maximum blood flow velocity
Cal(1)=max(max(ImageAve.*ArtMask));
% Cross-sectional vessel area
Cal(2)=sum(sum(ArtMask)).*prod(Para.para.ROI*10)./prod(Para.para.size);
% Blood flow by velocity times area
Cal(3)=sum(sum(ImageAve.*ArtMask)).*prod(Para.para.ROI)./prod(Para.para.size)*60;
Para.Res=Cal;
y=Para;
end